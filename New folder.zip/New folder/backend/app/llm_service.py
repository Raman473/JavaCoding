import os
from pathlib import Path
from typing import Dict

try:
    import httpx
    from langchain_openai import ChatOpenAI  # type: ignore
    from langchain_core.messages import HumanMessage
except ImportError:  # pragma: no cover - optional dependency guard
    httpx = None
    ChatOpenAI = None
    HumanMessage = None

PROMPTS_DIR = Path(__file__).resolve().parent.parent / "prompts"

STAGE_MODELS: Dict[str, str] = {
    "frd": "genailab-maas-gpt-5.4",
    "ssd": "gemini-2.5-pro",
    "dsl": "genailab-maas-gpt-5.4",
    "architecture": "gemini-2.5-pro",
    "database": "genailab-maas-gpt-5.4",
    "code": "genailab-maas-gpt-5.3-codex",
    "tests": "genailab-maas-gpt-5.3-codex",
    "quality": "azure_ai/genailab-maas-DeepSeek-R1",
}


def _load_prompt(stage: str) -> str:
    prompt_path = PROMPTS_DIR / f"{stage}.txt"
    if prompt_path.exists():
        return prompt_path.read_text(encoding="utf-8")
    return f"Generate the {stage} deliverable from the provided requirements."


def _fallback_content(stage: str, project_name: str, requirements_text: str) -> str:
    summary = requirements_text.strip().splitlines()[0] if requirements_text.strip() else "Requirements provided"
    return (
        f"{stage.upper()} draft for {project_name}\n\n"
        f"Summary: {summary}\n\n"
        "This content was generated from the uploaded requirements using the local fallback workflow because no LLM endpoint was configured."
    )


def generate_stage_content(stage: str, project_name: str, requirements_text: str) -> str:
    prompt_text = _load_prompt(stage)
    user_prompt = (
        f"Project Name: {project_name}\n"
        f"Stage: {stage}\n\n"
        f"Requirements Document:\n{requirements_text}\n\n"
        "Use the instructions below to generate the deliverable.\n\n"
        f"{prompt_text}"
    )

    base_url = os.getenv("SDLC_LLM_BASE_URL") or os.getenv("OPENAI_BASE_URL")
    api_key = os.getenv("SDLC_LLM_API_KEY") or os.getenv("OPENAI_API_KEY")
    model = STAGE_MODELS.get(stage, "genailab-maas-gpt-5.4")

    if not base_url or not api_key or ChatOpenAI is None or HumanMessage is None or httpx is None:
        return _fallback_content(stage, project_name, requirements_text)

    try:
        client = httpx.Client(timeout=60.0)
        llm = ChatOpenAI(base_url=base_url, model=model, api_key=api_key, http_client=client)
        response = llm.invoke([HumanMessage(content=user_prompt)])
        content = getattr(response, "content", None)
        if isinstance(content, list):
            return "\n".join(str(part) for part in content)
        if content is None:
            return str(response)
        return str(content).strip() or _fallback_content(stage, project_name, requirements_text)
    except Exception as exc:
        return _fallback_content(stage, project_name, requirements_text) + f"\n\nLLM fallback due to error: {exc}"
