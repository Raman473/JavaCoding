import json
import os
import re
import shutil
import uuid
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional

from docx import Document
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pypdf import PdfReader

from .llm_service import generate_stage_content

ROOT = Path(__file__).resolve().parent.parent
UPLOAD_ROOT = ROOT / "uploads"
STORAGE_ROOT = ROOT / "storage"
PROJECTS_FILE = STORAGE_ROOT / "projects.json"

UPLOAD_ROOT.mkdir(parents=True, exist_ok=True)
STORAGE_ROOT.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="SDLC Orchestrator", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _load_projects() -> Dict[str, Any]:
    if PROJECTS_FILE.exists():
        return json.loads(PROJECTS_FILE.read_text(encoding="utf-8"))
    return {}


def _save_projects(projects: Dict[str, Any]) -> None:
    PROJECTS_FILE.write_text(json.dumps(projects, indent=2), encoding="utf-8")


def _project_dir(project_id: str) -> Path:
    project_dir = UPLOAD_ROOT / project_id
    project_dir.mkdir(parents=True, exist_ok=True)
    return project_dir


def _read_text(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".txt":
        return path.read_text(encoding="utf-8", errors="ignore")
    if suffix == ".pdf":
        reader = PdfReader(str(path))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    if suffix == ".docx":
        document = Document(path)
        return "\n".join(paragraph.text for paragraph in document.paragraphs if paragraph.text.strip())
    return path.read_text(encoding="utf-8", errors="ignore")


def _extract_requirements(text: str) -> List[str]:
    cleaned = re.sub(r"\s+", " ", text).strip()
    if not cleaned:
        return []
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", cleaned) if s.strip()]
    requirements = []
    for sentence in sentences:
        lower = sentence.lower()
        if any(keyword in lower for keyword in ["must", "should", "require", "need", "user", "system"]):
            requirements.append(sentence)
    if not requirements:
        requirements = sentences[:8]
    return requirements[:10]


def _build_summary(text: str) -> str:
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]
    if not sentences:
        return "Requirements uploaded and ready for review."
    return sentences[0]


def _write_docx(path: Path, title: str, summary: str, requirements: List[str]) -> None:
    document = Document()
    document.add_heading(title, level=1)
    document.add_paragraph(summary)
    document.add_heading("Key Requirements", level=2)
    for requirement in requirements:
        document.add_paragraph(requirement, style="List Bullet")
    document.save(path)


def _write_plain_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


def _write_docx_from_text(path: Path, title: str, content: str) -> None:
    document = Document()
    document.add_heading(title, level=1)
    for line in content.splitlines():
        if line.strip():
            document.add_paragraph(line)
    document.save(path)


def _create_zip(path: Path, project_name: str, content: str) -> None:
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(f"{project_name.lower().replace(' ', '_')}/README.txt", f"Generated starter source files for the approved architecture.\n\n{content}")
        archive.writestr(f"{project_name.lower().replace(' ', '_')}/app.py", "print('Hello from the generated SDLC starter code')\n")


def _artifact_payload(step: str, project: Dict[str, Any], preview_text: str, filename: str) -> Dict[str, Any]:
    return {
        "step": step,
        "filename": filename,
        "preview": preview_text,
        "created_at": project.get("updated_at"),
    }


def _build_steps(project: Dict[str, Any]) -> List[Dict[str, Any]]:
    approved = set(project.get("approved_steps", []))
    artifacts = project.get("artifacts", {})

    step_order = ["upload", "frd", "ssd", "wireframes", "dsl", "architecture", "database", "code", "tests", "rtm", "quality"]

    def state_for(step: str) -> Dict[str, Any]:
        if step == "upload":
            return {
                "key": step,
                "label": "Upload Requirements",
                "status": "completed" if project.get("documents") else "pending",
                "enabled": True,
            }

        index = step_order.index(step)
        if step == "frd":
            return {
                "key": step,
                "label": "Generate FRD",
                "status": "approved" if "frd" in approved else "generated" if "frd" in artifacts else "pending",
                "enabled": bool(project.get("documents")),
            }

        previous_step = step_order[index - 1]
        return {
            "key": step,
            "label": {
                "ssd": "Generate SSD",
                "wireframes": "Generate Wireframes",
                "dsl": "Generate DSL",
                "architecture": "Generate Architecture",
                "database": "Generate Database Design",
                "code": "Generate Code",
                "tests": "Generate Test Cases",
                "rtm": "Generate RTM",
                "quality": "Quality Analysis",
            }[step],
            "status": "approved" if step in approved else "generated" if step in artifacts else "pending",
            "enabled": previous_step in approved,
        }
        return {"key": step, "label": step, "status": "pending", "enabled": False}

    return [
        state_for("upload"),
        state_for("frd"),
        state_for("ssd"),
        state_for("wireframes"),
        state_for("dsl"),
        state_for("architecture"),
        state_for("database"),
        state_for("code"),
        state_for("tests"),
        state_for("rtm"),
        state_for("quality"),
    ]


@app.post("/api/projects")
def create_project(payload: Dict[str, Any]):
    project_id = str(uuid.uuid4())
    project = {
        "id": project_id,
        "name": payload.get("name", "Untitled Project"),
        "documents": [],
        "extracted_text": "",
        "artifacts": {},
        "approved_steps": [],
        "created_at": payload.get("created_at") or "",
    }
    projects = _load_projects()
    projects[project_id] = project
    _save_projects(projects)
    return {"project": project, "steps": _build_steps(project)}


@app.get("/api/projects/{project_id}")
def get_project(project_id: str):
    projects = _load_projects()
    project = projects.get(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return {"project": project, "steps": _build_steps(project)}


@app.post("/api/projects/{project_id}/documents")
async def upload_documents(project_id: str, files: List[UploadFile] = File(...)):
    projects = _load_projects()
    project = projects.get(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    project_dir = _project_dir(project_id)
    for existing_file in project_dir.iterdir():
        if existing_file.is_file():
            existing_file.unlink()

    uploaded_documents = []
    text_chunks = []
    for upload in files:
        file_path = project_dir / upload.filename
        with file_path.open("wb") as handle:
            shutil.copyfileobj(upload.file, handle)
        uploaded_documents.append({"name": upload.filename, "path": str(file_path)})
        text_chunks.append(_read_text(file_path))

    project["documents"] = uploaded_documents
    project["extracted_text"] = "\n\n".join(text_chunks)
    projects[project_id] = project
    _save_projects(projects)
    return {"project": project, "steps": _build_steps(project)}


@app.post("/api/projects/{project_id}/generate/{step}")
def generate_artifact(project_id: str, step: str):
    projects = _load_projects()
    project = projects.get(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    if not project.get("documents"):
        raise HTTPException(status_code=400, detail="Upload requirements first")

    requirements = _extract_requirements(project.get("extracted_text", ""))
    summary = _build_summary(project.get("extracted_text", ""))
    base_dir = _project_dir(project_id)
    llm_content = generate_stage_content(step, project["name"], project.get("extracted_text", ""))

    if step == "frd":
        filename = f"{project['name']}_FRD.docx"
        doc_path = base_dir / filename
        text_path = base_dir / f"{project['name']}_FRD.txt"
        _write_docx_from_text(doc_path, f"FRD for {project['name']}", llm_content)
        _write_plain_text(text_path, llm_content)
        project["artifacts"][step] = _artifact_payload(step, project, llm_content, filename)

    elif step == "ssd":
        filename = f"{project['name']}_SSD.docx"
        doc_path = base_dir / filename
        text_path = base_dir / f"{project['name']}_SSD.txt"
        _write_docx_from_text(doc_path, f"SSD for {project['name']}", llm_content)
        _write_plain_text(text_path, llm_content)
        project["artifacts"][step] = _artifact_payload(step, project, llm_content, filename)

    elif step == "wireframes":
        filename = f"{project['name']}_Wireframes.txt"
        path = base_dir / filename
        _write_plain_text(path, llm_content)
        project["artifacts"][step] = _artifact_payload(step, project, llm_content, filename)

    elif step == "dsl":
        filename = f"{project['name']}_DSL.yaml"
        path = base_dir / filename
        _write_plain_text(path, llm_content)
        project["artifacts"][step] = _artifact_payload(step, project, llm_content, filename)

    elif step == "architecture":
        filename = f"{project['name']}_Architecture.md"
        path = base_dir / filename
        _write_plain_text(path, llm_content)
        project["artifacts"][step] = _artifact_payload(step, project, llm_content, filename)

    elif step == "database":
        filename = f"{project['name']}_Database.sql"
        path = base_dir / filename
        _write_plain_text(path, llm_content)
        project["artifacts"][step] = _artifact_payload(step, project, llm_content, filename)

    elif step == "code":
        filename = f"{project['name']}_SourceCode.zip"
        path = base_dir / filename
        _create_zip(path, project["name"], llm_content)
        preview_text = llm_content[:500]
        project["artifacts"][step] = _artifact_payload(step, project, preview_text, filename)

    elif step == "tests":
        filename = f"{project['name']}_TestCases.txt"
        path = base_dir / filename
        _write_plain_text(path, llm_content)
        project["artifacts"][step] = _artifact_payload(step, project, llm_content, filename)

    elif step == "rtm":
        filename = f"{project['name']}_RTM.csv"
        path = base_dir / filename
        _write_plain_text(path, llm_content)
        project["artifacts"][step] = _artifact_payload(step, project, llm_content, filename)

    elif step == "quality":
        filename = f"{project['name']}_QualityReport.txt"
        path = base_dir / filename
        _write_plain_text(path, llm_content)
        project["artifacts"][step] = _artifact_payload(step, project, llm_content, filename)

    else:
        raise HTTPException(status_code=400, detail="Unsupported step")

    project["updated_at"] = str(Path().cwd())
    projects[project_id] = project
    _save_projects(projects)
    return {"project": project, "steps": _build_steps(project)}


@app.post("/api/projects/{project_id}/approve/{step}")
def approve_step(project_id: str, step: str):
    projects = _load_projects()
    project = projects.get(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    if step not in project.get("artifacts", {}):
        raise HTTPException(status_code=400, detail="Generate the artifact before approval")
    if step not in project.get("approved_steps", []):
        project.setdefault("approved_steps", []).append(step)
    projects[project_id] = project
    _save_projects(projects)
    return {"project": project, "steps": _build_steps(project)}


@app.post("/api/projects/{project_id}/approve/all")
def approve_all(project_id: str):
    projects = _load_projects()
    project = projects.get(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    approved_steps = set(project.get("approved_steps", []))
    for step in project.get("artifacts", {}):
        approved_steps.add(step)
    project["approved_steps"] = sorted(approved_steps)
    projects[project_id] = project
    _save_projects(projects)
    return {"project": project, "steps": _build_steps(project)}


@app.get("/api/projects/{project_id}/download/{step}")
def download_artifact(project_id: str, step: str):
    projects = _load_projects()
    project = projects.get(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    artifact = project.get("artifacts", {}).get(step)
    if not artifact:
        raise HTTPException(status_code=404, detail="Artifact not generated")
    file_path = _project_dir(project_id) / artifact["filename"]
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Artifact file missing")
    return {"download_url": f"/api/projects/{project_id}/files/{artifact['filename']}"}


@app.get("/api/projects/{project_id}/files/{filename}")
def serve_file(project_id: str, filename: str):
    from fastapi.responses import FileResponse

    file_path = _project_dir(project_id) / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(file_path)
