Architecture overview:
- Frontend (React)
- Backend (FastAPI)
- Orchestrator (approval-based workflow)