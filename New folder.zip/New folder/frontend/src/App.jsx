import { useMemo, useState } from 'react';

const LABELS = {
  upload: 'Upload Requirements',
  frd: 'Generate FRD',
  ssd: 'Generate SSD',
  wireframes: 'Generate Wireframes',
  dsl: 'Generate DSL',
  architecture: 'Generate Architecture',
  database: 'Generate Database Design',
  code: 'Generate Code',
  tests: 'Generate Test Cases',
  rtm: 'Generate RTM',
  quality: 'Quality Analysis'
};

function App() {
  const [project, setProject] = useState(null);
  const [steps, setSteps] = useState([]);
  const [name, setName] = useState('');
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeStep, setActiveStep] = useState('upload');
  const [message, setMessage] = useState('Create a project to start the SDLC flow.');

  const selectedStep = useMemo(() => {
    if (!steps.length) return null;
    return steps.find((step) => step.key === activeStep) ?? steps[0];
  }, [activeStep, steps]);

  const createProject = async (event) => {
    event.preventDefault();
    const projectName = name.trim() || 'Untitled Project';
    setLoading(true);
    const response = await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: projectName })
    });
    const payload = await response.json();
    setProject(payload.project);
    setSteps(payload.steps);
    setActiveStep('upload');
    setMessage('Project created. Upload your requirements documents next.');
    setLoading(false);
  };

  const uploadDocuments = async () => {
    if (!project || !selectedFiles.length) {
      setMessage('Choose at least one file to upload.');
      return;
    }
    setLoading(true);
    const formData = new FormData();
    selectedFiles.forEach((file) => formData.append('files', file));
    const response = await fetch(`/api/projects/${project.id}/documents`, {
      method: 'POST',
      body: formData
    });
    const payload = await response.json();
    setProject(payload.project);
    setSteps(payload.steps);
    setActiveStep('frd');
    setMessage('Documents uploaded and parsed. FRD generation is now available.');
    setLoading(false);
  };

  const runStep = async (stepKey) => {
    if (!project) return;
    setLoading(true);
    const response = await fetch(`/api/projects/${project.id}/generate/${stepKey}`, { method: 'POST' });
    const payload = await response.json();
    setProject(payload.project);
    setSteps(payload.steps);
    setActiveStep(stepKey);
    setMessage(`${LABELS[stepKey]} generated successfully.`);
    setLoading(false);
  };

  const approveStep = async (stepKey) => {
    if (!project) return;
    setLoading(true);
    const response = await fetch(`/api/projects/${project.id}/approve/${stepKey}`, { method: 'POST' });
    const payload = await response.json();
    setProject(payload.project);
    setSteps(payload.steps);
    setActiveStep(stepKey);
    setMessage(`${LABELS[stepKey]} approved. The next stage is now unlocked.`);
    setLoading(false);
  };

  const downloadArtifact = async (stepKey) => {
    if (!project) return;
    const response = await fetch(`/api/projects/${project.id}/download/${stepKey}`);
    const payload = await response.json();
    window.open(payload.download_url, '_blank');
  };

  const renderActions = () => {
    if (!selectedStep) return null;
    const artifact = project?.artifacts?.[selectedStep.key];
    const isEnabled = selectedStep.enabled;
    const isApproved = project?.approved_steps?.includes(selectedStep.key);

    if (selectedStep.key === 'upload') {
      return (
        <div className="actions">
          <span className="helper-text">Upload your requirements document to start the workflow.</span>
        </div>
      );
    }

    return (
      <div className="actions">
        <button disabled={!isEnabled || loading} onClick={() => runStep(selectedStep.key)}>
          {artifact ? 'Regenerate' : 'Generate'}
        </button>
        <button disabled={!artifact || isApproved || loading} onClick={() => approveStep(selectedStep.key)}>
          Approve
        </button>
        <button disabled={!artifact || loading} onClick={() => downloadArtifact(selectedStep.key)}>
          Download
        </button>
      </div>
    );
  };

  return (
    <div className="app-shell">
      <header className="header-card">
        <div>
          <p className="eyebrow">Approval-based SDLC Pipeline</p>
          <h1>Requirements to Delivery</h1>
          <p className="subtle">A lightweight orchestrator that mirrors a waterfall-style workflow with human approval checkpoints.</p>
        </div>
        <div className="project-summary">
          {project ? (
            <>
              <strong>{project.name}</strong>
              <span>Requirements workflow</span>
            </>
          ) : (
            <span>No active project</span>
          )}
        </div>
      </header>

      <section className="panel-grid">
        <div className="panel">
          <h2>Create Project</h2>
          <form onSubmit={createProject} className="form-stack">
            <label>
              Project Name
              <input value={name} onChange={(event) => setName(event.target.value)} placeholder="Enter project name" />
            </label>
            <button type="submit" disabled={loading}>Create Project</button>
          </form>

          <div className="upload-card">
            <h3>Upload Requirements</h3>
            <input type="file" multiple onChange={(event) => setSelectedFiles(Array.from(event.target.files || []))} />
            <button disabled={!project || !selectedFiles.length || loading} onClick={uploadDocuments}>Upload Documents</button>
          </div>
        </div>

        <div className="panel">
          <h2>Pipeline Steps</h2>
          <div className="stepper">
            {steps.map((step) => {
              const isActive = activeStep === step.key;
              const isApproved = project?.approved_steps?.includes(step.key);
              const isGenerated = Boolean(project?.artifacts?.[step.key]);
              return (
                <button
                  key={step.key}
                  className={`step-item ${isActive ? 'active' : ''} ${step.enabled ? '' : 'disabled'}`}
                  onClick={() => setActiveStep(step.key)}
                  disabled={!step.enabled}
                >
                  <span className="step-badge">
                    {isApproved ? '✓' : isGenerated ? '•' : '○'}
                  </span>
                  <span>{LABELS[step.key]}</span>
                </button>
              );
            })}
          </div>
          <div className="message-box">{message}</div>
        </div>
      </section>

      {selectedStep && (
        <section className="panel detail-panel">
          <div className="detail-header">
            <div>
              <p className="eyebrow">Current Stage</p>
              <h2>{LABELS[selectedStep.key]}</h2>
            </div>
            <div className="status-pill">
              {project?.approved_steps?.includes(selectedStep.key) ? 'Approved' : project?.artifacts?.[selectedStep.key] ? 'Generated' : 'Pending'}
            </div>
          </div>

          {renderActions()}

          {project?.artifacts?.[selectedStep.key] ? (
            <div className="artifact-card">
              <h3>Generated Output</h3>
              <p className="artifact-name">{project.artifacts[selectedStep.key].filename}</p>
              <pre>{project.artifacts[selectedStep.key].preview}</pre>
            </div>
          ) : (
            <div className="artifact-card empty">
              <h3>No artifact yet</h3>
              <p>Generate this stage to create the deliverable and unlock the next approval point.</p>
            </div>
          )}
        </section>
      )}
    </div>
  );
}

export default App;
