import { useEffect, useState } from 'react';

const API_BASE = '/api';

function App() {
  const [projectName, setProjectName] = useState('Portable Project');
  const [project, setProject] = useState(null);
  const [steps, setSteps] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const createProject = async () => {
    setLoading(true);
    const response = await fetch(`${API_BASE}/projects`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: projectName, created_at: new Date().toISOString() })
    });
    const data = await response.json();
    setProject(data.project);
    setSteps(data.steps);
    setMessage('Project created.');
    setLoading(false);
  };

  const uploadDocuments = async () => {
    if (!project || selectedFiles.length === 0) return;
    setLoading(true);
    const formData = new FormData();
    selectedFiles.forEach((file) => formData.append('files', file));
    const response = await fetch(`${API_BASE}/projects/${project.id}/documents`, {
      method: 'POST',
      body: formData
    });
    const data = await response.json();
    setProject(data.project);
    setSteps(data.steps);
    setMessage('Requirements uploaded.');
    setLoading(false);
  };

  const generateStep = async (step) => {
    if (!project) return;
    setLoading(true);
    const response = await fetch(`${API_BASE}/projects/${project.id}/generate/${step}`, { method: 'POST' });
    const data = await response.json();
    setProject(data.project);
    setSteps(data.steps);
    setMessage(`${step.toUpperCase()} generated.`);
    setLoading(false);
  };

  const approveStep = async (step) => {
    if (!project) return;
    setLoading(true);
    const response = await fetch(`${API_BASE}/projects/${project.id}/approve/${step}`, { method: 'POST' });
    const data = await response.json();
    setProject(data.project);
    setSteps(data.steps);
    setMessage(`${step.toUpperCase()} approved.`);
    setLoading(false);
  };

  const downloadArtifact = async (step) => {
    const response = await fetch(`${API_BASE}/projects/${project.id}/download/${step}`);
    const data = await response.json();
    window.open(`${API_BASE}/projects/${project.id}/files/${data.download_url.split('/').pop()}`, '_blank');
  };

  return (
    <div className="app-shell">
      <h1>SDLC Orchestrator</h1>
      <p>Portable workflow demo for requirements to artifacts.</p>
      <div className="card">
        <label>Project name</label>
        <input value={projectName} onChange={(e) => setProjectName(e.target.value)} />
        <button onClick={createProject} disabled={loading}>Create project</button>
      </div>

      {project && (
        <div className="card">
          <h2>{project.name}</h2>
          <input type="file" multiple onChange={(e) => setSelectedFiles(Array.from(e.target.files || []))} />
          <button onClick={uploadDocuments} disabled={loading}>Upload requirements</button>
          <p>{message}</p>
        </div>
      )}

      {steps.length > 0 && (
        <div className="card">
          <h2>Workflow</h2>
          <ol>
            {steps.map((step) => (
              <li key={step.key} className={`step ${step.status}`}>
                <div>
                  <strong>{step.label}</strong>
                  <div>Status: {step.status}</div>
                </div>
                <div className="step-actions">
                  <button onClick={() => generateStep(step.key)} disabled={loading || !step.enabled}>Generate</button>
                  <button onClick={() => approveStep(step.key)} disabled={loading || !project?.artifacts?.[step.key]}>Approve</button>
                  <button onClick={() => downloadArtifact(step.key)} disabled={loading || !project?.artifacts?.[step.key]}>Download</button>
                </div>
              </li>
            ))}
          </ol>
        </div>
      )}
    </div>
  );
}

export default App;
