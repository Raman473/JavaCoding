# Portable SDLC Orchestrator Release

This folder contains a portable copy of the SDLC Orchestrator project for use in another VS Code workspace.

## What to do in the new workspace

### 1) Create a Python virtual environment
```bash
python -m venv .venv
.\.venv\Scripts\activate
```

### 2) Install backend dependencies
```bash
pip install -r backend/requirements.txt
```

### 3) Install frontend dependencies
```bash
cd frontend
npm install
```

### 4) Start backend
```bash
cd ..
.\.venv\Scripts\python.exe -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8010
```

### 5) Start frontend
```bash
cd frontend
npm run dev -- --host 127.0.0.1
```

Open:
- Frontend: http://127.0.0.1:3000
- Backend: http://127.0.0.1:8010/docs
